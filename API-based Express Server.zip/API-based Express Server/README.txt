
API-based Express Server

\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
Student;

Wajahat Ghumman

wajahat.ghumman@outlook.com



///////////////////////////////////////////////////////////////////////////////

version node.js
tested it on linux.

Install: sudo apt install npm

To install npm modules execute:
>npm install

This will install the modules listed as dependencies in the package.json file.

To run either execute
>npm start
or 
>node server.js


(just in case you don't have it already)(
Install: npm install express.js
)

launch(final): node server.js

*****************************************************************************
To Test:

http://localhost:3000
http://localhost:3000/
http://localhost:3000/recipes.html
http://localhost:3000/recipes
http://localhost:3000/index.html



\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

sources...

W3schools

//////////////////////////////////////////////////////////////////////////////



Everything should be good.
API Key might be expired but i think you guys will use your own.


\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\





function getRecipes() {

    let recipes = document.getElementById('ingredient').value


    let recipesDiv = document.getElementById('recipes')
    recipesDiv.innerHTML = ''

    let xhr = new XMLHttpRequest()
    xhr.onreadystatechange = () => {
        if (xhr.readyState == 4 && xhr.status == 200) {
            let response = JSON.parse(xhr.responseText)


      for(var j = 0 ; j<response.recipes.length; j++ ){

        //this will put the data on the web

        /*these are the general settings, allignments, colorings, words, links etc*/
        recipesDiv.innerHTML = recipesDiv.innerHTML + `



        <div class="gallery">
        <a target = "_blank" href= ${response.recipes[j].f2f_url}>
        <img src = ${response.recipes[j].image_url} width ="1200" height="800">
        </a>
        <div class="desc"> ${response.recipes[j].title.bold()}
        </div>

        <style>
        div.gallery {
          margin: 15px;
          border: 2px solid #000;
          float: left;
          width: 450px;
          color: black;
          background-color: skyblue;
          font-size:15px;
        }

        div.gallery:hover {
          border: 2px solid #999;
        }

        div.gallery:hover {
          -ms-transform: scale(1.2); /* IE 9 */
          -webkit-transform: scale(1.2); /* Safari 3-8 */
           transform: scale(1.2);
        }

        div.gallery img {
          width: 100%;
          height: 350px;
        }

        div.desc {
          padding: 15px;
          text-align: center;
        }
        </style>

        `





      }

        }
    }
    let ingredient = document.getElementById('ingredient').value
    //xhr.open('GET', `https://food2fork.com/api/search?key=f2bfc68845d48b541c314b55f731dca3&q=${ingredient}`, true)
    xhr.open('GET', `/recipes?ingredient=${ingredient}`, true)
    //xhr.setRequestHeader('Content-Type', 'text/javascript')
    xhr.send()
}

//Attach Enter-key Handler
const ENTER=13
document.getElementById("recipes")
    .addEventListener("keyup", function(event) {
    event.preventDefault();
    if (event.keyCode === ENTER) {
        document.getElementById("submit").click();
    }
});
